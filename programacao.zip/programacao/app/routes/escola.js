var express = require('express');
var router = express.Router();
var authenticate = require('../controller/authenticate');
var escola_controller = require('../controller/escola')

router.use(authenticate.apiAuth);

//Cadastrar escola
router.post('/insert', escola_controller.insert);

//Buscar escola
router.post('/select', escola_controller.select);

//Deletar escola
router.get('/export', escola_controller.export);

//Deletar escola
router.post('/delete', escola_controller.delete);

module.exports = router;
