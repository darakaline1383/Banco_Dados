var express = require('express');
var router = express.Router();
var authenticate = require('../controller/authenticate');
var escola_controller = require('../controller/escola')

router.use(authenticate.apiAuth);

//Cadastrar escola
router.post('/insertEscola', escola_controller.insertEscola);

//Cadastrar NRC
router.post('/insertNRC', escola_controller.insertNRC);

//Cadastrar corrdenador
router.post('/insertCoordenador', escola_controller.insertCoordenador);

//Buscar escola
router.post('/selectEscola', escola_controller.selectEscola);

//Buscar coordenador
router.post('/selectCoordenador', escola_controller.selectCoordenador);

//Buscar NRC
router.post('/selectNRC', escola_controller.selectNRC);

//Exṕortar escola
router.get('/export', escola_controller.export);

//Exṕortar escola
router.get('/exportNRC', escola_controller.exportNRC);

//Exṕortar escola
router.get('/exportCoordenador', escola_controller.exportCoordenador);

//Deletar escola
router.post('/deleteEscola', escola_controller.deleteEscola);

//Deletar nrc
router.post('/deleteNRC', escola_controller.deleteNRC);

//Deletar coordenador
router.post('/deleteCoordenador', escola_controller.deleteCoordenador);

//Update escola
router.post('/updateEscola', escola_controller.updateEscola);

module.exports = router;
