var express = require('express');
var router = express.Router();
var authenticate = require('../controller/authenticate')

//Rota padrão criada pelo express para inicialização da aplicação
router.get('/', authenticate.auth, function(req, res) {
  res.render('escola_cadastro');
});

//Rota padrão criada pelo express para inicialização da aplicação
router.get('/coordenadorNRC', authenticate.auth, function(req, res) {
  res.render('pessoa_coordenador');
});

//Verifica se o usuario fez login, em caso afirmativo: entra na pag principal, senão fica em login
router.get('/login', function(req, res) {
  if (req.session.userid) {
    res.redirect('escola_cadastro')
  } else {
    res.render('login');
  }
});

module.exports = router;
