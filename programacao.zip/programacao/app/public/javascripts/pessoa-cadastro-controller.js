function atualizaPessoaNRC() {
    var xhttp = new XMLHttpRequest();
  
    var paginationAtual = $('#atual').val();
  
    var object = {
      pagination: paginationAtual
    }
  
    xhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
        switch (this.status) {
          case 200:
            valorMaximoPag(JSON.parse(this.response).contador.count);
            addElementsToTable(JSON.parse(this.response).result);
            break;
  
          case 304:
            valorMaximoPag(JSON.parse(this.response).contador.count);
            addElementsToTable(JSON.parse(this.response).result);
            break;
  
          case 500:
            setTimeout(() => {
              $("#totalRegistros").val('0 registros.')
            }, 1500);
            break;
  
          default:
            setTimeout(() => {
              $("#totalRegistros").val('0 registros.')
            }, 1500);
            break;
        }
      }
    }
    xhttp.open('POST', '/escola/select', true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(object));
  }
  
  function addElementsToTable(rows) {
    //Pegar referencia da tabela de escolas
    const table = document.querySelector('#tabelaescola tbody');
  
    while (table.hasChildNodes()) {
      table.removeChild(table.firstChild);
    }
  
    for (var i = 0; i < rows.length; i++) {
      var newRow = table.insertRow(i)
      var count = 0
  
      var actionCell = newRow.insertCell(count)
  
      //Celula do nome do coordenador
      var nomeCoordenadorCell = newRow.insertCell(count)
      var nomeCoordenadorValue = document.createTextNode(rows[i].nome_coordenador)
      nomeCoordenadorCell.appendChild(nomeCoordenadorValue)
      count++;
  
      //Celula do RG do coordenador
      var rgCoordenadorCell = newRow.insertCell(count)
      var rgCoordenadorValue = document.createTextNode(rows[i].rg)
      rgCoordenadorCell.appendChild(rgCoordenadorValue)
      count++;

      //Celula do nome da Pessoa NRC
      var nomeNRCCell = newRow.insertCell(count)
      var nomeNRCValue = document.createTextNode(rows[i].nome)
      nomeNRCCell.appendChild(nomeNRCValue)
      count++;

      //Celula do nome da Pessoa NRC
      var cargoNRCCell = newRow.insertCell(count)
      var cargoNRCValue = document.createTextNode(rows[i].cargo)
      cargoNRCCell.appendChild(cargoNRCValue)
      count++;
  
      // botao excluir
      var excluirCell = newRow.insertCell(count)
      var excluirElement = document.createElement('input')
      excluirElement.setAttribute('type', 'button')
      excluirElement.setAttribute('value', 'Excluir')
      excluirElement.classList.add('btn')
      excluirElement.classList.add('btn-outline')
      excluirElement.classList.add('btn-danger')
      excluirElement.classList.add('dim')
      excluirElement.onclick = deleteItem(rows[i])
      excluirCell.appendChild(excluirElement)
    }
  }
  
  function deleteItem(item) {
    return function () {
  
      var xhttp = new XMLHttpRequest();
      xhttp.open('POST', '/escola/deleteNRC')
  
      var object = {
        coordenador_id: item.id
      }
  
      xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
          switch (this.status) {
            case 200:
              sucessSwal(JSON.parse(this.response).message);
              setTimeout(() => {
                location.reload();
              }, 1500);
              break;
  
            case 304:
              sucessSwal(JSON.parse(this.response).message);
              setTimeout(() => {
                location.reload();
              }, 1500);
              break;
  
            case 400:
              alertSwal(JSON.parse(this.response).message);
              break;
  
            case 500:
              alertSwal(JSON.parse(this.response).message);
              break;
  
            case 404:
              alertSwal('Não foi possível alcançar o servidor');
              break;
  
            default:
              alertSwal('Erro inesperado, contate o administrador');
              break;
          }
        }
      }
      xhttp.setRequestHeader('Content-Type', 'application/json')
      xhttp.send(JSON.stringify(object));
    }
  }
  
  function validarCadastro() {
    var nomeCoordenador = $("#nomeCoordenador").val();
    var rgCoordenador = $("#rgCoordenador").val();
    var pessoaNRC = $("#pessoaNRC").val();
    var pessoaNRCCargo = $("#pessoaNRCCargo").val();
  
    //Validando o campo nome da escola
    if (nomeEscola == "" || nomeEscola == null) {
      alertSwal('Nome da escola não pode estar vazio!');
      return false;
    }
  
    var object = {
      nomeCoordenador: nomeCoordenador,
      rgCoordenador: rgCoordenador,
      pessoaNRC: pessoaNRC,
      pessoaNRCCargo: pessoaNRCCargo
    }
  
      var xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
          switch (this.status) {
            case 200:
              sucessSwal("Sucesso ao cadastro!");
              break;
  
            case 304:
              sucessSwal("Sucesso ao cadastro!");
              break;
  
            case 400:
              alertSwal(JSON.parse(this.response).message);
              break;
  
            case 500:
              alertSwal(JSON.parse(this.response).message);
              break;
  
            case 404:
              alertSwal('Não foi possível alcançar o servidor');
              break;
  
            case 200:
              window.open("/", "_self");
              break;
  
            default:
              alertSwal('Erro inesperado, contate o administrador');
              break;
          }
        }
      }
      xhttp.open("POST", '/escola/insertNRC', true);
      xhttp.setRequestHeader("Content-type", "application/json");
      xhttp.send(JSON.stringify(object));
  }
  
  function exportarCSV() {
    var xhttp = new XMLHttpRequest();
    xhttp.open('GET', '/escola/export', true);
  
    xhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
        switch (this.status) {
          case 200:
            montarExportarTabelaCSV(JSON.parse(this.response));
            break;
  
          case 304:
            montarExportarTabelaCSV(JSON.parse(this.response));
            break;
  
          case 500:
            alertSwal(JSON.parse(this.response).message);
            break;
  
          default:
            alertSwal('Erro inesperado, contate o administrador.');
            break;
        }
      }
    }
    xhttp.send();
  }
  
  function montarExportarTabelaCSV(rows) {
    //Mostrar que o processo pode demorar
    swal({
      title: "Exportar CSV",
      text: "Este processo pode demorar um tempo!"
    });
  
    var csv = 'Nome escola, Cidade escola,Data de exporte,\n';
  
    for (var i = 0; i < rows.length; i++) {
      csv += rows[i].nome;
      csv += ',' + rows[i].cidade;
      csv += '\n';
    }
  
    var hiddenElement = document.createElement('a');
    hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
    hiddenElement.target = '_blank';
    hiddenElement.download = 'Escola.csv';
    hiddenElement.click();
  }
  
  function alertSwal(message) {
    swal({
      title: "Ops :(",
      text: message,
      type: "error",
      showConfirmButton: true
    });
  }
  
  function sucessSwal(message) {
    swal({
      title: "Sucesso :)",
      text: message,
      type: "success",
      timer: 4500,
    },
      function () {
        swal.close();
      });
  }
  
  function gatilhoContMenos() {
    $('#contMais').attr('disabled', false);
    var valorMaximo = $('#valorMaximo').val();
  
    var paginationAtual = parseInt($('#atual').val());
  
    if (paginationAtual > 0) {
      var atual = paginationAtual - 1;
      $('#atual').val(atual);
    }
  
    if (paginationAtual == 1) {
      $('#atual').val(1);
      $('#contMenos').attr('disabled', true);
    }
  
    atualizaPessoaNRC();
  }
  
  function gatilhoContMais() {
    $('#contMenos').attr('disabled', false);
    var valorMaximo = $('#valorMaximo').val();
    var paginationAtual = parseInt($('#atual').val());
  
    if (paginationAtual < valorMaximo) {
      var atual = paginationAtual + 1;
      $('#atual').val(atual);
    }
  
    if (paginationAtual == valorMaximo) {
      $('#contMais').attr('disabled', true);
      $('#atual').val(valorMaximo);
    }
  
    atualizaPessoaNRC();
  }
  
  function gatilhoPaginacaoProximo() {
    $('#contMenos').attr('disabled', false);
    var valorMaximo = $('#valorMaximo').val();
    var paginationAtual = parseInt($('#atual').val());
  
    if (paginationAtual < valorMaximo) {
      var atual = paginationAtual + 1;
      $('#atual').val(atual);
    }
  
    if (paginationAtual == valorMaximo) {
      $('#atual').val(valorMaximo);
      $('#contMais').attr('disabled', true);
    }
  
    atualizaPessoaNRC();
  }
  
  function valorMaximoPag(page) {
    var totalRegistros = $('#totalRegistros');
    totalRegistros.val(page + " registros.");
  
    page /= 10;
    if (page % 1 == 0) {
      page = page;
    } else {
      page = Math.ceil(page);
    }
  
    var valorMaximo = $('#valorMaximo');
  
    if (page == 0) {
      valorMaximo.val(1);
    } else {
      valorMaximo.val(page);
    }
  
    if ($('#atual').val() > page) {
      $('#atual').val(1);
      $('#contMenos').click();
    }
  }
  