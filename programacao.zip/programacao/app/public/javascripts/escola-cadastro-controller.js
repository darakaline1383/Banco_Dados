function atualizaEscola() {
  var xhttp = new XMLHttpRequest();

  var paginationAtual = $('#atual').val();

  var object = {
    pagination: paginationAtual
  }

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          valorMaximoPag(JSON.parse(this.response).contador.count);
          addElementsToTable(JSON.parse(this.response).result);
          break;

        case 304:
          valorMaximoPag(JSON.parse(this.response).contador.count);
          addElementsToTable(JSON.parse(this.response).result);
          break;

        case 500:
          setTimeout(() => {
            $("#totalRegistros").val('0 registros.')
          }, 1500);
          break;

        default:
          setTimeout(() => {
            $("#totalRegistros").val('0 registros.')
          }, 1500);
          break;
      }
    }
  }
  xhttp.open('POST', '/escola/selectEscola', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function addElementsToTable(rows) {
  //Pegar referencia da tabela de escolas
  const table = document.querySelector('#tabelaescola tbody');

  while (table.hasChildNodes()) {
    table.removeChild(table.firstChild);
  }

  for (var i = 0; i < rows.length; i++) {
    var newRow = table.insertRow(i)
    var count = 0

    var actionCell = newRow.insertCell(count)

    //Celula do id da escola
    var idEscolaCell = newRow.insertCell(count)
    var idEscolaValue = document.createTextNode(rows[i].id)
    idEscolaCell.appendChild(idEscolaValue)
    count++;

    //Celula do nome da escola
    var nomeEscolaCell = newRow.insertCell(count)
    var nomeEscolaValue = document.createTextNode(rows[i].nome)
    nomeEscolaCell.appendChild(nomeEscolaValue)
    count++;

    //Celula da cidade da escola
    var cidadeEscolaCell = newRow.insertCell(count)
    var cidadeEscolaValue = document.createTextNode(rows[i].cidade)
    cidadeEscolaCell.appendChild(cidadeEscolaValue)
    count++;

    // botao editar
    var editarCell = newRow.insertCell(count)
    var editarElement = document.createElement('input')
    editarElement.setAttribute('type', 'button')
    editarElement.setAttribute('value', 'Editar')
    editarElement.classList.add('btn')
    editarElement.classList.add('btn-outline')
    editarElement.classList.add('btn-success')
    editarElement.classList.add('dim')
    editarElement.setAttribute('data-toggle', "modal");
    editarElement.setAttribute('data-target', "#modalEditarInfoEscola");
    editarElement.setAttribute('title', "Editar informações da escola");
    editarElement.onclick = editItem(rows[i])
    editarCell.appendChild(editarElement)

    // botao excluir
    var excluirCell = newRow.insertCell(count)
    var excluirElement = document.createElement('input')
    excluirElement.setAttribute('type', 'button')
    excluirElement.setAttribute('value', 'Excluir')
    excluirElement.classList.add('btn')
    excluirElement.classList.add('btn-outline')
    excluirElement.classList.add('btn-danger')
    excluirElement.classList.add('dim')
    excluirElement.onclick = deleteItem(rows[i])
    excluirCell.appendChild(excluirElement)
  }
}

function editItem(item) {
  return function () {
    //Abrir o modal para exibir as informações de edição da escola
    $('#modalEditarInfoEscola').on('shown.bs.modal', function () {

      var date = new Date();
      var dataHoje = ((date.getDate() < 10 ? '0' : '') + date.getDate()) + "/" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '') + "/" + date.getFullYear();
      $("#dataHoje").val("Hoje: " + dataHoje);

      //colocando as informações nos campos do modal
      $("#modalTitle").text("Edição da escola: " + item.nome);

      //Informações da escola
      $("#modalNomeEscola").val(item.nome);
      $("#modalCidadeEscola").val(item.cidade);
      $("#modalIdCoordenadorEscola").val(item.coordenador_rg_fk);

      var btnSalvarEdicao = document.getElementById("salvarEdicao");
      btnSalvarEdicao.addEventListener("click", function (event) {

        var xhttp = new XMLHttpRequest();
        xhttp.open('POST', '/escola/updateEscola')

        var object = {
          escola_id: item.id,
          nome: $("#modalNomeEscola").val(),
          cidade: $("#modalCidadeEscola").val(),
          pessoa_id: $("#modalIdCoordenadorEscola").val()
        }

        xhttp.onreadystatechange = function () {
          if (this.readyState == 4) {
            switch (this.status) {
              case 200:
                sucessSwal(JSON.parse(this.response).message);
                setTimeout(() => {
                  location.reload();
                }, 1500);
                break;

              case 304:
                sucessSwal(JSON.parse(this.response).message);
                setTimeout(() => {
                  location.reload();
                }, 1500);
                break;

              case 400:
                alertSwal(JSON.parse(this.response).message);
                break;

              case 500:
                alertSwal(JSON.parse(this.response).message);
                break;

              case 404:
                alertSwal('Não foi possível alcançar o servidor');
                break;

              default:
                alertSwal('Erro inesperado, contate o administrador');
                break;
            }
          }
        }
        xhttp.setRequestHeader('Content-Type', 'application/json')
        xhttp.send(JSON.stringify(object));
      })
    });
  }
}

function deleteItem(item) {
  return function () {

    var xhttp = new XMLHttpRequest();
    xhttp.open('POST', '/escola/deleteEscola')

    var object = {
      escola_id: item.id
    }

    xhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
        switch (this.status) {
          case 200:
            sucessSwal(JSON.parse(this.response).message);
            setTimeout(() => {
              location.reload();
            }, 1500);
            break;

          case 304:
            sucessSwal(JSON.parse(this.response).message);
            setTimeout(() => {
              location.reload();
            }, 1500);
            break;

          case 400:
            alertSwal(JSON.parse(this.response).message);
            break;

          case 500:
            alertSwal(JSON.parse(this.response).message);
            break;

          case 404:
            alertSwal('Não foi possível alcançar o servidor');
            break;

          default:
            alertSwal('Erro inesperado, contate o administrador');
            break;
        }
      }
    }
    xhttp.setRequestHeader('Content-Type', 'application/json')
    xhttp.send(JSON.stringify(object));
  }
}

function validarCadastro() {
  var nomeEscola = $("#nomeEscola").val();
  var cidadeEscola = $("#cidadeEscola").val();
  var idCoordenadorEscola = $("#idCoordenadorEscola").val();

  //Validando o campo nome da escola
  if (nomeEscola == "" || nomeEscola == null) {
    alertSwal('Nome da escola não pode estar vazio!');
    return false;
  }

  var object = {
    nomeEscola: nomeEscola,
    cidadeEscola: cidadeEscola,
    idCoordenadorEscola: idCoordenadorEscola
  }

  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          sucessSwal("Sucesso ao cadastro!");
          break;

        case 304:
          sucessSwal("Sucesso ao cadastro!");
          break;

        case 400:
          alertSwal(JSON.parse(this.response).message);
          break;

        case 500:
          alertSwal(JSON.parse(this.response).message);
          break;

        case 404:
          alertSwal('Não foi possível alcançar o servidor');
          break;

        case 200:
          window.open("/", "_self");
          break;

        default:
          alertSwal('Erro inesperado, contate o administrador');
          break;
      }
    }
  }
  xhttp.open("POST", '/escola/insertEscola', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function exportarCSV() {
  var xhttp = new XMLHttpRequest();
  xhttp.open('GET', '/escola/export', true);

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          montarExportarTabelaCSV(JSON.parse(this.response));
          break;

        case 304:
          montarExportarTabelaCSV(JSON.parse(this.response));
          break;

        case 500:
          alertSwal(JSON.parse(this.response).message);
          break;

        default:
          alertSwal('Erro inesperado, contate o administrador.');
          break;
      }
    }
  }
  xhttp.send();
}

function montarExportarTabelaCSV(rows) {
  //Mostrar que o processo pode demorar
  swal({
    title: "Exportar CSV",
    text: "Este processo pode demorar um tempo!"
  });

  var date = new Date();
  var dataGrafico = ((date.getDate() < 10 ? '0' : '') + date.getDate()) + "/" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '') + "/" + date.getFullYear();

  var csv = 'Nome escola, Cidade escola,Data de exportação,\n';

  for (var i = 0; i < rows.length; i++) {
    csv += rows[i].nome;
    csv += ',' + rows[i].cidade;
    csv += ',' + dataGrafico;
    csv += '\n';
  }

  var hiddenElement = document.createElement('a');
  hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
  hiddenElement.target = '_blank';
  hiddenElement.download = 'Escola.csv';
  hiddenElement.click();
}

function alertSwal(message) {
  swal({
    title: "Ops :(",
    text: message,
    type: "error",
    showConfirmButton: true
  });
}

function sucessSwal(message) {
  swal({
    title: "Sucesso :)",
    text: message,
    type: "success",
    timer: 4500,
  },
    function () {
      swal.close();
      location.reload();
    });
}

function gatilhoContMenos() {
  $('#contMais').attr('disabled', false);
  var valorMaximo = $('#valorMaximo').val();

  var paginationAtual = parseInt($('#atual').val());

  if (paginationAtual > 0) {
    var atual = paginationAtual - 1;
    $('#atual').val(atual);
  }

  if (paginationAtual == 1) {
    $('#atual').val(1);
    $('#contMenos').attr('disabled', true);
  }

  atualizaEscola();
}

function gatilhoContMais() {
  $('#contMenos').attr('disabled', false);
  var valorMaximo = $('#valorMaximo').val();
  var paginationAtual = parseInt($('#atual').val());

  if (paginationAtual < valorMaximo) {
    var atual = paginationAtual + 1;
    $('#atual').val(atual);
  }

  if (paginationAtual == valorMaximo) {
    $('#contMais').attr('disabled', true);
    $('#atual').val(valorMaximo);
  }

  atualizaEscola();
}

function gatilhoPaginacaoProximo() {
  $('#contMenos').attr('disabled', false);
  var valorMaximo = $('#valorMaximo').val();
  var paginationAtual = parseInt($('#atual').val());

  if (paginationAtual < valorMaximo) {
    var atual = paginationAtual + 1;
    $('#atual').val(atual);
  }

  if (paginationAtual == valorMaximo) {
    $('#atual').val(valorMaximo);
    $('#contMais').attr('disabled', true);
  }

  atualizaEscola();
}

function valorMaximoPag(page) {
  var totalRegistros = $('#totalRegistros');
  totalRegistros.val(page + " registros.");

  page /= 10;
  if (page % 1 == 0) {
    page = page;
  } else {
    page = Math.ceil(page);
  }

  var valorMaximo = $('#valorMaximo');

  if (page == 0) {
    valorMaximo.val(1);
  } else {
    valorMaximo.val(page);
  }

  if ($('#atual').val() > page) {
    $('#atual').val(1);
    $('#contMenos').click();
  }
}
