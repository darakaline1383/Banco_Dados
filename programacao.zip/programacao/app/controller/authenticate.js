module.exports = {
  apiAuth: (req, res, next) => {
    if (req.session.userid) {
      next();
    } else {
      return res.status(401).send({
        error: 'User not allowed',
        message: 'Usuário não está autenticado, por favor faça login no sistema'
      });
    }
  },

  auth: (req, res, next) => {
    if (req.session.userid) {
      next();
    } else {
      res.redirect('login');
    }
  }
}
