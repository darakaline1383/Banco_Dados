const pg = require('../db')
const crypto = require('crypto');

module.exports = {
  validate_user: (req, res) => {

    if (!req.body.username && !req.body.password)
    return res.status(400).send()
    var username = req.body.username
    var password = toHash(req.body.password)

    pg.query('SELECT usuario_id FROM usuario WHERE usuario_login = ' +
    '$1 AND usuario_senha = $2;', [username, password], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro interno, por favor contacte o administrador'
        })
      }
      else {
        if (ans.rowCount == 1) {
          req.session.userid = ans.rows[0].usuario_id
          res.send()
        } else {
          res.status(401).send({
            error: 'User not allowed',
            message: 'Usuário ou senha inválidas'
          })
        }
      }
    })
  },

  signout: (req, res) => {
    req.session.destroy(function () {
      res.redirect('/');
    });
  }
}

function toHash(data) {

  const hash = crypto.createHash('sha512');

  hash.update(data);

  return hash.digest('hex');
}
