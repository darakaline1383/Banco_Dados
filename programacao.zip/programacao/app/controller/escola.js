const pg = require('../db');
var cont = 0;

module.exports = {
  insert: (req, res) => {
    var nomeEscola = req.body.nomeEscola;
    var cidadeEscola = req.body.cidadeEscola;

    if (!nomeEscola)
      return res.status(400).send();

    try {

      var query = 'INSERT INTO escola(id, nome, cidade, coordenador_id) VALUES ('
        + cont + ", "
        + "'" + nomeEscola + "', "
        + "'" + cidadeEscola + "', "
        + 1 + ");";
      cont++;
      pg.query(query, [], (err, ans) => {
        if (err) {
          console.log(err)
          return res.status(500).send({
            error: 'Erro interno',
            message: 'Erro interno na inserção'
          });
        } else {
          res.status(200).send({
            message: 'Escola configurada com sucesso!'
          });
        }
      });

    } catch (error) {
      console.log("\n\nError: " + error)
      return res.status(500).send({
        error: 'Erro interno',
        message: 'Erro interno, por favor contacte o administrador'
      });
    }
  },

  insertNRC: (req, res) => {
    var nomeCoordenador = req.body.nomeCoordenador;
    var rgCoordenador = req.body.rgCoordenador;
    var pessoaNRC = req.body.rgCoordenador;
    var pessoaNRCCargo = req.body.rgCoordenador;

    try {

      var query = 'INSERT INTO pessoa_responsavel_NRC(id, nome, cargo) VALUES ('
        + cont + ", "
        + "'" + pessoaNRC + "', "
        + "'" + pessoaNRCCargo + "');";
      cont++;
      pg.query(query, [], (err, ans) => {
        if (err) {
          console.log(err)
          return res.status(500).send({
            error: 'Erro interno',
            message: 'Erro interno na inserção'
          });
        } else {

          var query = 'INSERT INTO coordenador(id, nome_coordenador, rg, pessoa_id) VALUES ('
            + cont-1 + ", "
            + "'" + nomeCoordenador + "', "
            + "'" + rgCoordenador 
            + 1 + ");";
          cont++;
          pg.query(query, [], (err, ans) => {
            if (err) {
              console.log(err)
              return res.status(500).send({
                error: 'Erro interno',
                message: 'Erro interno na inserção'
              });
            } else {
              res.status(200).send({
                message: 'Coordenador e NRC configurados com sucesso!'
              });
            }
          });

          res.status(200).send({
            message: 'Coordenador e NRC configurados com sucesso!'
          });
        }
      });

    } catch (error) {
      console.log("\n\nError: " + error)
      return res.status(500).send({
        error: 'Erro interno',
        message: 'Erro interno, por favor contacte o administrador'
      });
    }
  },

  select: (req, res) => {
    //Buscar quantidade de escolas cadastradas
    var queryQtdescola = 'SELECT COUNT(id) FROM escola';

    pg.query(queryQtdescola, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      } else {
        //Quantidade retornada da consulta
        var count = ans.rows[0];

        //Verificar se não tem escola cadastrada
        if (count.count == 0) {
          return res.status(500).send({
            contador: count,
            message: 'Nenhuma escola cadastrada!'
          });
        } else {
          //paginacao no front-end
          var pagination = req.body.pagination;

          if (pagination == null || pagination == 1) {
            pagination = 0;
          } else if (pagination > 1) {
            pagination = pagination * 10 - 10;
          }
          var query = 'SELECT * FROM escola ORDER BY id DESC LIMIT 10 OFFSET ' + pagination;

          pg.query(query, [], (err, ans) => {
            if (err) {
              console.log("\n\nError: " + err)
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {
              var data = new Object();
              data.contador = count;
              data.result = ans.rows;
              res.json(data);
            }
          });
        }
      }
    });
  },

  delete: (req, res) => {
    var escola_id = req.body.escola_id;

    //Deletar a escola agora propriamente dito
    var query = `DELETE FROM escola WHERE id = ${escola_id}`;
    pg.query(query, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao deletar dados no servidor'
        });
      } else {
        //Executar o comando de exclusao da escola
        res.json({
          message: 'Escola excluída com sucesso!'
        });
      }
    });
  },

  deleteNRC: (req, res) => {
    var coordenador_id = req.body.coordenador_id;

    //Deletar a escola agora propriamente dito
    var query = `DELETE FROM coordenador WHERE id = ${coordenador_id}`;
    pg.query(query, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao deletar dados no servidor'
        });
      } else {
        //Executar o comando de exclusao da escola
        res.json({
          message: 'Coordenador excluído com sucesso!'
        });
      }
    });
  },

  export: (req, res) => {
    //Buscar quantidade de escolas cadastradas
    var queryQtdescola = 'SELECT COUNT(id) FROM escola';

    pg.query(queryQtdescola, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      } else {
        //Quantidade retornada da consulta
        var count = ans.rows[0];

        //Verificar se não tem escola cadastrada
        if (count.count == 0) {
          return res.status(500).send({
            contador: count,
            message: 'Nenhuma escola cadastrada!'
          });
        } else {
          //Query de busca 'da companha
          var query = 'SELECT * FROM escola ORDER BY id DESC';

          pg.query(query, [], (err, ans) => {
            if (err) {
              console.log("\n\nError: " + err)
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {
              res.json(ans.rows);
            }
          });
        }
      }
    });
  }
}
