const pg = require('../db');
var cont = 0;

module.exports = {
  insertEscola: (req, res) => {
    var nomeEscola = req.body.nomeEscola;
    var cidadeEscola = req.body.cidadeEscola;
    var idCoordenadorEscola = req.body.idCoordenadorEscola;

    if (!nomeEscola)
      return res.status(400).send();

    try {

      var query = 'INSERT INTO escola(nome, cidade, coordenador_rg_fk) VALUES ('
        + "'" + nomeEscola + "', "
        + "'" + cidadeEscola + "', "
        + idCoordenadorEscola + ");";
      pg.query(query, [], (err, ans) => {
        if (err) {
          console.log(err)
          return res.status(500).send({
            error: 'Erro interno',
            message: 'Erro interno na inserção'
          });
        } else {
          res.status(200).send({
            message: 'Escola configurada com sucesso!'
          });
        }
      });

    } catch (error) {
      console.log("\n\nError: " + error)
      return res.status(500).send({
        error: 'Erro interno',
        message: 'Erro interno, por favor contacte o administrador'
      });
    }
  },

  insertNRC: (req, res) => {
    var pessoaNRC = req.body.pessoaNRC;
    var pessoaNRCCargo = req.body.pessoaNRCCargo;

    try {

      var query = 'INSERT INTO pessoa_responsavel_NRC(nome, cargo) VALUES ('
        + "'" + pessoaNRC + "', "
        + "'" + pessoaNRCCargo + "');";
      pg.query(query, [], (err, ans) => {
        if (err) {
          console.log(err)
          return res.status(500).send({
            error: 'Erro interno',
            message: 'Erro interno na inserção'
          });
        } else {
          res.status(200).send({
            message: 'NRC configurado com sucesso!'
          });
        }
      });

    } catch (error) {
      console.log("\n\nError: " + error)
      return res.status(500).send({
        error: 'Erro interno',
        message: 'Erro interno, por favor contacte o administrador'
      });
    }
  },

  insertCoordenador: (req, res) => {
    var nomeCoordenador = req.body.nomeCoordenador;
    var rgCoordenador = req.body.rgCoordenador;
    var pessoaNRC = req.body.idNRCCoordenador;

    try {
      var query = 'INSERT INTO coordenador(nome_coordenador, rg, pessoa_id_fk) VALUES ('
        + "'" + nomeCoordenador + "', "
        + "'" + rgCoordenador + "', "
        + pessoaNRC + ");";
      console.log("\n" + query + "\n")
      pg.query(query, [], (err, ans) => {
        if (err) {
          console.log(err)
          return res.status(500).send({
            error: 'Erro interno',
            message: 'Erro interno na inserção'
          });
        } else {
          res.status(200).send({
            message: 'Coordenador configurado com sucesso!'
          });
        }
      });

    } catch (error) {
      console.log("\n\nError: " + error)
      return res.status(500).send({
        error: 'Erro interno',
        message: 'Erro interno, por favor contacte o administrador'
      });
    }
  },

  selectEscola: (req, res) => {
    //Buscar quantidade de escolas cadastradas
    var queryQtdescola = 'SELECT COUNT(id) FROM escola';

    pg.query(queryQtdescola, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      } else {
        //Quantidade retornada da consulta
        var count = ans.rows[0];

        //Verificar se não tem escola cadastrada
        if (count.count == 0) {
          return res.status(500).send({
            contador: count,
            message: 'Nenhuma escola cadastrada!'
          });
        } else {
          //paginacao no front-end
          var pagination = req.body.pagination;

          if (pagination == null || pagination == 1) {
            pagination = 0;
          } else if (pagination > 1) {
            pagination = pagination * 10 - 10;
          }
          var query = 'SELECT * FROM escola ORDER BY id DESC LIMIT 10 OFFSET ' + pagination;

          pg.query(query, [], (err, ans) => {
            if (err) {
              console.log("\n\nError: " + err)
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {
              var data = new Object();
              data.contador = count;
              data.result = ans.rows;
              res.json(data);
            }
          });
        }
      }
    });
  },

  selectNRC: (req, res) => {
    //Buscar quantidade de escolas cadastradas
    var queryQtdescola = 'SELECT COUNT(id) FROM pessoa_responsavel_nrc';

    pg.query(queryQtdescola, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      } else {
        //Quantidade retornada da consulta
        var count = ans.rows[0];

        //Verificar se não tem escola cadastrada
        if (count.count == 0) {
          return res.status(500).send({
            contador: count,
            message: 'Nenhum NRC cadastrada!'
          });
        } else {
          //paginacao no front-end
          var pagination = req.body.pagination;

          if (pagination == null || pagination == 1) {
            pagination = 0;
          } else if (pagination > 1) {
            pagination = pagination * 10 - 10;
          }
          var query = 'SELECT * FROM pessoa_responsavel_nrc ORDER BY id DESC LIMIT 10 OFFSET ' + pagination;

          pg.query(query, [], (err, ans) => {
            if (err) {
              console.log("\n\nError: " + err)
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {
              var data = new Object();
              data.contador = count;
              data.result = ans.rows;
              res.json(data);

            }
          });
        }
      }
    });
  },

  selectCoordenador: (req, res) => {
    //Buscar quantidade de escolas cadastradas
    var queryQtdescola = 'SELECT COUNT(id) FROM coordenador';

    pg.query(queryQtdescola, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      } else {
        //Quantidade retornada da consulta
        var count = ans.rows[0];

        //Verificar se não tem escola cadastrada
        if (count.count == 0) {
          return res.status(500).send({
            contador: count,
            message: 'Nenhum coordenador cadastrado!'
          });
        } else {
          //paginacao no front-end
          var pagination = req.body.pagination;

          if (pagination == null || pagination == 1) {
            pagination = 0;
          } else if (pagination > 1) {
            pagination = pagination * 10 - 10;
          }
          var query = 'SELECT * FROM coordenador ORDER BY id DESC LIMIT 10 OFFSET ' + pagination;

          pg.query(query, [], (err, ans) => {
            if (err) {
              console.log("\n\nError: " + err)
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {
              var data = new Object();
              data.contador = count;
              data.result = ans.rows;
              res.json(data);
            }
          });
        }
      }
    });
  },

  deleteEscola: (req, res) => {
    var escola_id = req.body.escola_id;

    //Deletar a escola agora propriamente dito
    var query = `DELETE FROM escola WHERE id = ${escola_id}`;
    pg.query(query, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao deletar dados no servidor'
        });
      } else {
        //Executar o comando de exclusao da escola
        res.json({
          message: 'Escola excluída com sucesso!'
        });
      }
    });
  },

  deleteNRC: (req, res) => {
    var pessoa_id = req.body.pessoa_id;

    //Deletar a escola agora propriamente dito
    var query = `DELETE FROM pessoa_responsavel_nrc WHERE id = ${pessoa_id}`;
    pg.query(query, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao deletar dados no servidor'
        });
      } else {
        //Executar o comando de exclusao da escola
        res.json({
          message: 'NRC excluído com sucesso!'
        });
      }
    });
  },

  deleteCoordenador: (req, res) => {
    var coordenador_id = req.body.coordenador_id;

    //Deletar a escola agora propriamente dito
    var query = `DELETE FROM coordenador WHERE id = ${coordenador_id}`;
    pg.query(query, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao deletar dados no servidor'
        });
      } else {
        //Executar o comando de exclusao da escola
        res.json({
          message: 'Coordenador excluído com sucesso!'
        });
      }
    });
  },

  export: (req, res) => {
    //Buscar quantidade de escolas cadastradas
    var queryQtdescola = 'SELECT COUNT(id) FROM escola';

    pg.query(queryQtdescola, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      } else {
        //Quantidade retornada da consulta
        var count = ans.rows[0];

        //Verificar se não tem escola cadastrada
        if (count.count == 0) {
          return res.status(500).send({
            contador: count,
            message: 'Nenhuma escola cadastrada, não há jeito de exportar dados.'
          });
        } else {
          //Query de busca 'da companha
          var query = 'SELECT * FROM escola ORDER BY id DESC';

          pg.query(query, [], (err, ans) => {
            if (err) {
              console.log("\n\nError: " + err)
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {
              res.json(ans.rows);
            }
          });
        }
      }
    });
  },

  exportNRC: (req, res) => {
    //Buscar quantidade de escolas cadastradas
    var queryQtdescola = 'SELECT COUNT(id) FROM pessoa_responsavel_nrc';

    pg.query(queryQtdescola, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      } else {
        //Quantidade retornada da consulta
        var count = ans.rows[0];

        //Verificar se não tem escola cadastrada
        if (count.count == 0) {
          return res.status(500).send({
            contador: count,
            message: 'Nenhum NRC cadastrada, não há jeito de exportar dados.'
          });
        } else {

          var query = 'SELECT * FROM pessoa_responsavel_nrc ORDER BY id DESC';

          pg.query(query, [], (err, ans) => {
            if (err) {
              console.log("\n\nError: " + err)
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {
              var data = new Object();
              data.contador = count;
              data.result = ans.rows;
              res.json(data);

            }
          });
        }
      }
    });
  },

  updateEscola: (req, res) => {
    //recebendo o id da escola
    var escola_id = req.body.escola_id;
    var nome = req.body.nome;
    var cidade = req.body.cidade;
    var pessoa_id = req.body.pessoa_id;

    var update = `UPDATE escola SET nome = '${nome}', cidade = '${cidade}', coordenador_rg_fk = ${pessoa_id} WHERE id = ${escola_id}`;
    console.log(update)
    pg.query(update, [], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao selecionar dados no servidor'
        });
      } else {
        res.json({
          message: 'Escola atualizada!'
        });
      }
    });
  },

  exportCoordenador: (req, res) => {
    //Buscar quantidade de escolas cadastradas
    var queryQtdescola = 'SELECT COUNT(id) FROM coordenador';

    pg.query(queryQtdescola, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      } else {
        //Quantidade retornada da consulta
        var count = ans.rows[0];

        //Verificar se não tem escola cadastrada
        if (count.count == 0) {
          return res.status(500).send({
            contador: count,
            message: 'Nenhum coordenador cadastrado, não há jeito de exportar dados.'
          });
        } else {
          var query = 'SELECT * FROM coordenador ORDER BY id DESC';

          pg.query(query, [], (err, ans) => {
            if (err) {
              console.log("\n\nError: " + err)
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {
              var data = new Object();
              data.contador = count;
              data.result = ans.rows;
              res.json(data);
            }
          });
        }
      }
    });

  }
}
