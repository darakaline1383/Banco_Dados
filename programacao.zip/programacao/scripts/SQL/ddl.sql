﻿DROP TABLE usuario 
CREATE TABLE usuario(
	usuario_id BIGSERIAL NOT NULL,
	usuario_login CHARACTER VARYING(20) NOT NULL UNIQUE,
	usuario_senha CHARACTER VARYING(128) NOT NULL,
	PRIMARY KEY (usuario_id)
);

INSERT INTO usuario(usuario_id,usuario_login,usuario_senha)
VALUES(1,'admin','353ba90f8c0b3e0f355a3d6c960b7caed5f2c1412992277c0669a04a62e7dfd35fba9f4631a7dc6d00fb44d93d305cc0b749c7501d9ce86f26148d05101b8324');

CREATE TABLE pessoa_responsavel_NRC(
    id BIGSERIAL NOT NULL,
    nome VARCHAR(45) NOT NULL,
    cargo VARCHAR(45) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE coordenador(
    id BIGSERIAL NOT NULL,
    nome_coordenador VARCHAR(45),
    rg VARCHAR(20) NOT NULL,
    pessoa_id_fk BIGINT NOT NULL,
    PRIMARY KEY (id)
);

ALTER TABLE coordenador ADD CONSTRAINT fk_pessoa_id FOREIGN KEY (pessoa_id_fk) REFERENCES pessoa_responsavel_NRC (id) ON UPDATE CASCADE ON DELETE CASCADE;   


CREATE TABLE escola(
    id BIGSERIAL NOT NULL,
    nome VARCHAR(45) NOT NULL,
    cidade VARCHAR(45) NOT NULL,
    coordenador_rg_fk BIGINT NOT NULL,
    serie VARCHAR(45),
    PRIMARY KEY (id)
);

ALTER TABLE escola ADD CONSTRAINT fk_coordenador_rg FOREIGN KEY (coordenador_rg_fk) REFERENCES coordenador (id) ON UPDATE CASCADE ON DELETE CASCADE;


CREATE TABLE aluno(
    id BIGSERIAL NOT NULL,
    nome VARCHAR(45) NOT NULL,
    idade VARCHAR(45) NOT NULL,
    escola_id_fk BIGINT NOT NULL,
    PRIMARY KEY (id)
);

ALTER TABLE aluno ADD CONSTRAINT fk_faculdade_id FOREIGN KEY (escola_id_fk) REFERENCES escola (id) ON UPDATE CASCADE ON DELETE CASCADE;

CREATE TABLE cursos_inatel(
	sigla VARCHAR(45),
    nome VARCHAR(45) NOT NULL,
    PRIMARY KEY (sigla)
);

CREATE TABLE monitor(
	id BIGSERIAL, 
    nome_monitor VARCHAR(45) NOT NULL,
    curso_monitor VARCHAR(45),
    PRIMARY KEY (id)
);

CREATE TABLE escola_has_monitor(
    escola_id BIGSERIAL NOT NULL,
    monitor_id BIGSERIAL NOT NULL,
    PRIMARY KEY (escola_id, monitor_id)
);

ALTER TABLE escola_has_monitor ADD CONSTRAINT fk_escola_id FOREIGN KEY (escola_id) REFERENCES escola(id) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE escola_has_monitor ADD CONSTRAINT fk_monitor_id FOREIGN KEY (monitor_id) REFERENCES monitor(id) ON UPDATE CASCADE ON DELETE CASCADE;
