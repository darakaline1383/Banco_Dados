﻿
create table pessoa_responsavel_NRC
(
    id int primary key,
    nome varchar(45) not null,
    cargo varchar(45) not null
    
)
create table coordenador
(
    id int primary key,
    nome_coordenador varchar(45),
    rg varchar(45) not null,
    pessoa_id int not null,
    constraint fk_pessoa_id foreign key (pessoa_id) references pessoa_responsavel_NRC (id) on update cascade   
)

create table escola
(
    id int primary key ,
    nome varchar(45) not null,
    cidade varchar(45) not null,
    coordenador_rg int,
    serie varchar(45),
    constraint fk_coordenador_rg foreign key (coordenador_rg) references coordenador (id) on update cascade
)

create table aluno
(
    id int primary key,
    nome varchar(45) not null,
    idade varchar(45) not null,
    escola_id int not null,
    serie_id int not null,
    constraint fk_faculdade_id foreign key (escola_id) references escola (id) on update cascade
);

create table cursos_inatel
(
	sigla varchar(45) primary key ,
    nome varchar(45) not null
    
    
);
create table monitor
(
	id int primary  key, 
    nome_monitor float not null,
    curso_monitor int not null
    
       
);

create table escola_has_monitor
(
    escola_id int not null,
    monitor_id int not null,
    primary key (escola_id, monitor_id),
    constraint fk_escola_id foreign key (escola_id) references escola(id) on update cascade,
    constraint fk_monitor_id foreign key (monitor_id) references monitor(id) on update cascade
);